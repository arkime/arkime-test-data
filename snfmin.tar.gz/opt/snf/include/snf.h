/*************************************************************************
 * The contents of this file are subject to the MYRICOM SNIFFER10G
 * LICENSE (the "License"); User may not use this file except in
 * compliance with the License.  The full text of the License can found
 * in LICENSE.TXT
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.  See
 * the License for the specific language governing rights and
 * limitations under the License.
 *
 * Copyright 2008-2009 by Myricom, Inc.  All rights reserved.
 ***********************************************************************/


#ifndef _snf_h
#define _snf_h

#ifndef MAL_KERNEL
#ifndef _WIN32
#include <stdint.h>
#else /* _WIN32 */
typedef signed __int8      int8_t;
typedef signed __int16    int16_t;
typedef signed __int32    int32_t;
typedef signed __int64    int64_t;
typedef unsigned __int8   uint8_t;
typedef unsigned __int16 uint16_t;
typedef unsigned __int32 uint32_t;
typedef unsigned __int64 uint64_t;
#ifdef _M_IX86
typedef unsigned __int32 uintptr_t;
#else
typedef unsigned __int64 uintptr_t;
#endif
#endif /* _WIN32 */
#else
#include "mal_int.h"
#endif

#ifdef __cplusplus
extern "C"
{
#endif

/**********************************************************************/
/* Control import/export of symbols and calling convention.           */
/**********************************************************************/
#ifndef _WIN32
#  define SNF_FUNC(type) type
#  define SNF_VAR(type) type
#else
#  ifdef SNF_BUILDING_LIB
#    ifdef __cplusplus
#      define SNF_FUNC(type) extern "C" __declspec(dllexport) type __cdecl
#      define SNF_VAR(type) extern "C" __declspec(dllexport) type
#    else
#      define SNF_FUNC(type) __declspec(dllexport) type __cdecl
#      define SNF_VAR(type) __declspec(dllexport) type
#    endif
#  else
#    ifdef __cplusplus
#      define SNF_FUNC(type) extern "C" __declspec(dllimport) type __cdecl
#      define SNF_VAR(type) extern "C" __declspec(dllimport) type
#    else
#      define SNF_FUNC(type) __declspec(dllimport) type __cdecl
#      define SNF_VAR(type) __declspec(dllimport) type
#    endif
#  endif
#endif



/**
 * SNF API version number (16 bits)
 * Least significant byte increases for minor backwards compatible changes
 * in the API. Most significant byte increases for incompatible changes in the API
 *
 * 0x0008: Add link speed support.
 *
 * 0x0007: Add Multiple Application support and snf_set_app_id() function.
 *
 * 0x0006: Internal driver/library API changes.
 *
 * 0x0005: Internal driver/library API changes.
 *
 * 0x0004: Add more injection support and aggregate port opens
 *
 * 0x0003: Add injection support and 3 send counters in statistics.
 *
 * 0x0002: Add nic_bytes_recv counter to stats to help users calculate the
 *         amount of bandwidth that is actually going through the NIC
 *         port.
 */
#define SNF_VERSION_API 8


typedef struct snf_handle *snf_handle_t;

/**
 * Initializes the sniffer library.
 *
 * @brief Initialize Sniffer Library with api_version == @ref SNF_VERSION_API
 *
 * @param api_version Must always be @ref SNF_VERSION_API
 *
 * @remarks This must be called before any other call to the sniffer
 *          library.
 * @remarks The library may be safely initialized multiple times, although
 *          the api_version should be the same SNF_VERSION_API each time.
 */
SNF_FUNC(int)  snf_init(uint16_t api_version); /* must be SNF_VERSION_API */

/**
 * Sets the application ID.
 *
 * @brief Set the application ID
 *
 * The user may set the application ID after the call to @ref snf_init, but
 * before @ref snf_open.  When the application ID is set, Sniffer duplicates
 * receive packets to multiple applications.  Each application must have
 * a unique ID.  Then, each application may utilize a different number of
 * rings.  The application can be a process with multiple rings and threads.
 * In this case all rings have the same ID.  Or, multiple processes may share
 * the same application ID.
 *
 * The user may store the application ID in the environment variable
 * SNF_APP_ID, instead of calling this function.  Both actions have the same
 * effect.  SNF_APP_ID overrides the ID set via snf_set_app_id.
 *
 * The user may not run a mix of processes with valid application IDs (not -1)
 * and processes with no IDs (-1).  Either all processes have valid IDs or
 * none of them do.
 *
 * @param id A 32-bit signed integer representing the application ID.
 *           A valid ID is any value except -1. -1 is reserved and represents
 *           "no ID".
 *
 * @retval 0      Successful
 * @retval EINVAL snf_init has not been called or id is -1.
 */
SNF_FUNC(int) snf_set_app_id(int32_t id);


enum snf_link_state { SNF_LINK_DOWN = 0, SNF_LINK_UP = 1 };


enum snf_timesource_state {
  SNF_TIMESOURCE_LOCAL = 0,  /**< Local timesource (no external). 
                                  Returned if there is no available external 
                                  timesource or if its use was explicitly disabled. */
  SNF_TIMESOURCE_EXT_UNSYNCED, /**< External Timesource: not synchronized (yet) */
  SNF_TIMESOURCE_EXT_SYNCED,   /**< External Timesource: synchronized */
  SNF_TIMESOURCE_EXT_FAILED,   /**< External Timesource: NIC failure to connect to source */
  SNF_TIMESOURCE_ARISTA_ACTIVE,/**< Arista switch is sending ptp timestamps */
  SNF_TIMESOURCE_PPS,          /**< PPS is being used for time */
};

/** Structure to map Interfaces to Sniffer port numbers */
struct snf_ifaddrs {
  struct snf_ifaddrs *snf_ifa_next;      /**< next item or NULL if last */
  const char *snf_ifa_name;       /**< interface name, as in ifconfig */
  uint32_t    snf_ifa_portnum;    /**< snf port number */
#define snf_ifa_boardnum snf_ifa_portnum
  int         snf_ifa_maxrings;   /**< Maximum RX rings supported */
  uint8_t     snf_ifa_macaddr[6]; /**< MAC address */
  uint8_t     pad[2];             /**< Internal padding (ignore) */
  int         snf_ifa_maxinject;  /**< Maximum TX injection handles supported */
  enum snf_link_state
              snf_ifa_link_state; /**< Underlying port's state (DOWN or UP) */
  uint64_t    snf_ifa_link_speed; /**< Link Speed (bps) */
};

/** 
 * Get a list of Sniffer-capable ethernet devices.
 *
 * @param ifaddrs_o Library-allocated list of Sniffer-capable devices
 *
 * @remarks Much like getifaddrs, the user can traverse the list until
 *          snf_ifa_next is NULL.  The interface will show up if the
 *          ethernet driver sees the device but the interface does not
 *          have to be brought up with an IP address (i.e. no need to
 *          'ifconfig up').
 *
 * @post User should call @ref snf_freeifaddrs to free the memory that was
 *       allocated by the library.
 */
SNF_FUNC(int)  snf_getifaddrs(struct snf_ifaddrs **ifaddrs_o);

/**
 * Free the list of library allocated memory for @ref snf_getifaddrs
 *
 * @param ifaddrs Pointer to ifaddrs allocated via @ref snf_getifaddrs
 */
SNF_FUNC(void) snf_freeifaddrs(struct snf_ifaddrs *ifaddrs);

/**
 * Get a mask of all Sniffer-capable ports.
 *
 * The least significant bit represents port 0.
 *
 * @param mask_o bitmask set at output
 * @param cnt_o  Number of bits set in bitmask
 *
 * @retval 0      Successful.
 * @retval ENODEV Error obtaining port information
 */
SNF_FUNC(int) snf_getportmask_valid(uint32_t *mask_o, int *cnt_o);

/**
 * Get a mask of all Sniffer-capable ports that have their link state set to UP
 *
 * The least significant bit represents port 0.
 *
 * Similar to @ref snf_getportmask_valid except that only ports with an
 * active link are set in the mask.
 *
 * @param mask_o bitmask set at output
 * @param cnt_o  Number of bits set in bitmask
 *
 * @retval 0      Successful.
 * @retval ENODEV Error obtaining port information
 */
SNF_FUNC(int) snf_getportmask_linkup(uint32_t *mask_o, int *cnt_o);

struct snf_recv_req;

/*! @defgroup rss_options Receive-Side Scaling (RSS)
 *
 * These options can be passed as parameters to @ref snf_open when RSS is used.
 * @{ */
/*! RSS select mode */
enum snf_rss_params_mode { 
  SNF_RSS_FLAGS = 0, /**< Apply RSS using specified flags */
  SNF_RSS_FUNCTION = 1 /**< Apply RSS using user-defined function: Kernel API only */
};

/*! RSS parameters for @ref SNF_RSS_FLAGS, flags that can be specified to let the
 * implementation know which fields are significant when generating the hash. By
 * default, RSS is computed on IPv4/IPv6 addresses and source/destination ports
 * when the protocol is TCP or UDP or SCTP, the equivalent of which would be 
 * @code
 * struct snf_rss_params rssp;
 * rssp.mode = SNF_RSS_FLAGS;
 * rssp.params.rss_flags = SNF_RSS_IP | SNF_RSS_SRC_PORT | SNF_RSS_DST_PORT;
 *
 * snf_handle_t hsnf;
 * int rc = snf_open(0, 0, &rssp, 0, -1, &hsnf);
 * if (rc == 0)
 *   printf("RSS will by applied to IP addresses and TCP/UDP ports if applicable");
 * @endcode
*/
enum snf_rss_mode_flags {
  SNF_RSS_IP        =  0x01, /**< Include IP (v4 or v6) SRC/DST addr in hash */
  SNF_RSS_SRC_PORT  =  0x10, /**< Include TCP/UDP/SCTP SRC port in hash */
  SNF_RSS_DST_PORT  =  0x20, /**< Include TCP/UDP/SCTP DST port in hash */
  SNF_RSS_GTP       =  0x40, /**< Include GTP TEID in hash */
  SNF_RSS_GRE       =  0x80, /**< Include GRE contents in hash */
};
#define SNF_RSS_IPV4 SNF_RSS_IP /**< Alias for @ref SNF_RSS_IP since IPv4 and 
                                   IPv6 are always both enabled */

/*! User-defined RSS hashing function parameters.
 * Users that provide their own callbacks can generate their own
 * hash based on the contents of a received packet.
 * @b NOTE This feature is available only in the SNF kernel API
 */
struct snf_rss_mode_function {
  /*! User-provided hash function. The callback is provided with a valid @ref
   * snf_recv_req structure which contains a packet as received by
   * Sniffer.  It is up to the user to inspect and parse the packet to
   * produce a unique 32-bit hash.  The implementation will map the 32-bit
   * into one of the rings allocated in @ref snf_open.  The function must
   * return one of three values
   * @li @b 0 The packet is queued in the ring based on the 32-bit hash
   *     value that is provided, which is hashval % num_rings.
   * @li @b <0 The packet is dropped and accounted as a drop in the ring
   *     corresponding to the 32-bit hash value provided by the user.
   *  
   * In the example below, we replace the default hash function with a
   * hash function that sends packets to different rings at every interval
   * of 500 packets.  This approach ignores the actual packet contents and
   * the importance of flow affinity, we just want to spread the packet
   * analysis to different rings and threads.
   *
   * @code
   * #define MAX_RINGS 32
   * #define PKT_INTERVAL 500
   * static uint32_t cnt[MAX_RINGS];
   * static uint32_t cur_ring = 0;
   *
   * static int
   * custom_hash(struct snf_recv_req *r, void *context, uint32_t *hashval)
   * {
   *    if (++cnt[cur_ring] == PKT_INTERVAL) {
   *       cnt[cur_ring] = 0;
   *       if (++cur_ring == MAX_RINGS)
   *          cur_ring = 0;
   *    }
   *    // Return cur_ring as the hash value, since Sniffer will apply a
   *    // modulo and the corresponding ring will receive the packet when
   *    // calling snf_recv()
   *    *hash_val = cur_ring;
   *    return 0; 
   * }
   *
   * // At snf_open time, select a custom hash approach.
   * struct snf_rss_params rssp;
   * rssp.mode = SNF_RSS_FUNCTION;
   * rssp.params.rss_function.rss_hash_fn = custom_hash;
   * rssp.params.rss_function.rss_context = NULL; // Don't need a context
   *
   * // On port 0, we will open MAX_RINGS rings, use default flags, 
   * // select an 800 MB data ring and chose our custom hashing function.
   * snf_handle_t hsnf;
   * int rc = snf_open(0, MAX_RINGS, &rssp, 800, 0, &hsnf);
   * if (rc) {
   *    perror("Error in snf_open");
   *    exit(EXIT_FAILURE);
   * }
   * @endcode
   */
  int   (*rss_hash_fn)(struct snf_recv_req *r, void *context, 
                       uint32_t *hashval);
  
  void   *rss_context;
};


struct snf_rss_params {
  enum snf_rss_params_mode mode; /**< RSS mode */
  union {
    enum snf_rss_mode_flags      rss_flags; /**< RSS parameters for @ref SNF_RSS_FLAGS */ 
    struct snf_rss_mode_function rss_function; /**< RSS params for @ref SNF_RSS_FUNCTION */
  } params; /**< RSS parameter settings, according to the mode that is selected */
};




/**
 * Device can be process-sharable.  This allows multiple independent
 * processes to share rings on the capturing device.  This option can be
 * used to design a custom capture solution but is also used in libpcap
 * when multiple rings are requested.  In this scenario, each libpcap
 * device sees a fraction of the traffic if multiple rings are used unless
 * the @ref SNF_F_RX_DUPLICATE option is used, in which case each libpcap
 * device sees the same incoming packets.
 */
#define SNF_F_PSHARED 0x1

/**
 * Device can be opened for port aggregation (or merging).  When this flag
 * is passed, the @b portnum parameter in @ref snf_open is interpreted as
 * a bitmask where each set bit position represents a port number.  The
 * Sniffer library will then attempt to open every portnum with its bit set
 * in order to merge the incoming data to the user from multiple ports.
 * Subsequent calls to @ref snf_ring_open return a ring handle that
 * internally opens a ring on all underlying ports.
 */
#define SNF_F_AGGREGATE_PORTMASK 0x2

/**
 * Device can duplicate packets to multiple rings as opposed to applying
 * RSS in order to split incoming packets across rings.  Users should be
 * aware that with N rings opened, N times the link bandwidth is necessary
 * to process incoming packets without drops.  The duplication happens in
 * the host rather than the NIC, so while only up to 10Gbits of traffic
 * crosses the PCIe, N times that bandwidth is necessary on the host.
 *
 * When duplication is enabled, RSS options are ignored since every packet
 * is delivered to every ring.
 */
#define SNF_F_RX_DUPLICATE 0x300



/**
 * Opens a port for sniffing and allocates a device handle.
 *
 * @brief Open device for single or multi-ring operation
 *
 * @param portnum  Port numbers can be interpreted as integers for a
 *                 specific port number or as a mask when
 *                 SNF_F_AGGREGATE_PORTMASK is specified in flags.  Port
 *                 information can be obtained through @ref snf_getifaddrs
 *                 and active/valid masks are available with 
 *                 @ref snf_getportmask_valid and 
 *                 @ref snf_getportmask_linkup.  As a special case, if
 *                 portnum -1 is passed, the library will internally open
 *                 a portmask as if @ref snf_getportmask_valid was called.
 *
 * @param num_rings Number of rings to allocate for receive-side scaling
 *                  feature, which determines how many different threads
 *                  can open their own ring via snf_ring_open().  If set
 *                  to 0 or less than zero, default value is used unless
 *                  SNF_NUM_RINGS is set in the environment.
 *
 * @param rss_params Points to a user-initialized structure that selects
 *                  the RSS mechanism to apply to each incoming packet.
 *                  This parameter is only meaningful if there are more
 *                  than 1 rings to be opened.  By default, if users pass
 *                  a NULL value, the implementation will select its own
 *                  mechanism to divide incoming packets across rings.
 *                  RSS parameters are documented in @ref rss_options.
 *
 * @param dataring_sz Represents the total amount of memory to be used to
 *                    store incoming packet data for *all* rings to be
 *                    opened.  If the value is set to 0 or less than 0,
 *                    the library tries to choose a sensible default
 *                    unless SNF_DATARING_SIZE is set in the environment.
 *                    The value can be specified in megabytes (if it is
 *                    less than 1048576) or is otherwise considered to be
 *                    in bytes.  In either case, the library may slightly
 *                    adjust the user's request to satisfy alignment
 *                    requirements (typically 2MB boundaries).
 *
 * @param flags A mask of flags documented in @ref snf_open_flags.
 *
 * @param devhandle Device handle allocated if the call is successful
 *
 * @retval 0      Successful. the port is opened and a value devhandle is
 *                allocated (see remarks)
 * @retval EBUSY  Device is already opened
 * @retval EINVAL Invalid argument passed, most probably num_rings (if
 *                not, check syslog)
 * @retval E2BIG  Driver could not allocate requested dataring_sz (check
 *                syslog)
 * @retval ENOMEM Either library or driver did not have enough memory to
 *                allocate handle descriptors (but not data ring).
 * @retval ENODEV Device portnum can't be opened 
 *
 * @post If successful, the NIC switches from Ethernet mode to Capture mode
 *       and the Ethernet driver stops receiving packets.
 *
 * @post If successful, a call to @ref snf_start is required to the
 *       Sniffer-mode NIC to deliver packets to the host, and this call
 *       must occur after at least one ring is opened (@ref
 *       snf_ring_open).
 */
SNF_FUNC(int) snf_open(uint32_t portnum,
             int num_rings,
             const struct snf_rss_params *rss_params,
             int64_t dataring_sz,
             int flags,
             snf_handle_t *devhandle);


/**
 * Opens a port for sniffing and allocates a device handle using system
 * defaults.
 *
 * @brief Open device for single or multi-ring operation
 *
 * This function is a simplified version of @ref snf_open and ensures that
 * the resulting device is opened according to system defaults.  Since
 * the number of rings and flags can be set by module parameters, some
 * installations may prefer to control device-level parameters in a
 * system-wide configuration and keep the library calls simple.
 *
 * This call is equivalent to
 * @code
 * snf_open(portnum, 0, NULL, 0, -1, devhandle);
 * @endcode
 *
 * @param portnum  Ports are numbered from 0 to N-1 where 'N' is the
 *                 number of Myricom ports available on the system.
 *                 snf_getifaddrs() may be a useful utility to retrieve
 *                 the port number by interface name or mac address if
 *                 there are multiple
 *
 * @param devhandle Device handle allocated if the call is successful
 *
 * @see snf_open
 */
SNF_FUNC(int) snf_open_defaults(uint32_t portnum, snf_handle_t *devhandle);

/**
 * Start packet capture on a port.  Packet capture is only started if it
 * is currently stopped or has not yet started for the first time.
 *
 * @param devhandle Device handle
 *
 * @remarks It is safe to restart packet capture via @ref snf_start and
 *          @ref snf_stop.
 * @remarks This call must be called before any packet can be received.
 */
SNF_FUNC(int) snf_start(snf_handle_t devhandle);

/**
 * Stop packet capture on a port.  This function should be used carefully
 * in multi-process mode as a single stop command stops packet capture on
 * all rings.  It is usually best to simply @ref snf_ring_close a ring to
 * stop capture on a ring.
 *
 * @param devhandle Device handle
 *
 * @remarks Stop instructs the NIC to drop all packets until the next @ref
 * snf_start() or until the port is closed.  The NIC only resumes
 * delivering packets when the port is closed, not when traffic is
 * stopped.
 */
SNF_FUNC(int) snf_stop(snf_handle_t devhandle);

/**
 * Get link status on opened handle
 *
 * @param devhandle Device handle
 * @param state Returns one of SNF_LINK_DOWN or SNF_LINK_UP
 *
 * @remarks The cost of retrieving the link state requires a function call
 *          that reads state kept in kernel host memory (i.e. no PCI bus
 *          reads).
 */
SNF_FUNC(int) snf_get_link_state(snf_handle_t devhandle, enum snf_link_state *state);

/**
 * Get Timesource information from opened handle
 *
 * @param devhandle Device handle
 * @param state Returns one of @ref snf_timesource_state
 *
 * @remarks The cost of retrieving the timesource state requires a
 *          function call that reads state kept in kernel host memory
 *          (i.e. no PCI bus reads).
 */
SNF_FUNC(int) snf_get_timesource_state(snf_handle_t devhandle,
                                       enum snf_timesource_state *state);

/**
 * Get link speed on opened handle
 *
 * @param devhandle Device handle
 * @param speed Returns speed in bits-per-second for the link
 *
 * @remarks The cost of retrieving the link speed requires a function call
 *          that reads information kept in kernel host memory (i.e. no PCI bus
 *          reads).
 */
SNF_FUNC(int) snf_get_link_speed(snf_handle_t devhandle, uint64_t *speed);

/**
 * @brief Close port
 *
 * This function can be closed once all opened rings (if any) are closed
 * through @ref snf_ring_close.  Once a port is determined to be
 * closable, it is implicitly called as if a call had been previously made
 * to @ref snf_stop.
 *
 * @retval 0 Successful.
 * @retval EBUSY  Some rings are still opened and the port cannot be
 *                closed (yet).
 *
 * @post If successful, all resources allocated at open time are
 * unallocated and the device switches from Sniffer mode to Ethernet mode
 * such that the Ethernet driver resumes receiving packets.
 */
SNF_FUNC(int) snf_close(snf_handle_t devhandle);


typedef struct snf_ring        *snf_ring_t;

/**
 * Opens the next available ring
 *
 * @param devhandle Device handle, obtained from a successful call to 
 *               @ref snf_open
 * @param ringh Ring handle allocated if the call is successful.
 *
 * @retval 0 Successful. The ring is opened and ringh contains the ring
 *           handle.
 * @retval EBUSY Too many rings already opened
 *
 * @remarks This function will consider the value of the SNF_RING_ID
 *          environment variable.  For more control over ring allocation,
 *          consider using @ref snf_ring_open_id instead.
 *
 * @post If successful, a call to @ref snf_start is required to the
 *       Sniffer-mode NIC to deliver packets to the host.
 */
SNF_FUNC(int) snf_ring_open(snf_handle_t devhandle, snf_ring_t *ringh);

/**
 * Opens a ring from an opened port.
 *
 * @param devhandle Device handle, obtained from a successful call to 
 *               @ref snf_open
 * @param ring_id Ring number to open, from 0 to @b num_rings - 1.  If
 *                the value is -1, this function behaves as if 
 *                @ref snf_ring_open was called.
 * @param ringh Ring handle allocated if the call is successful.
 *
 * @retval 0 Successful. The ring is opened and ringh contains the ring
 *           handle.
 * @retval EBUSY If ring_id == -1, Too many rings already opened.
 *               If ring_id >= 0, that ring is already opened.
 *
 * @remarks Unlike @ref snf_ring_open this function ignores the environment
 *          variable SNF_RING_ID since the expectation is that users want to
 *          directly control ring allocation (unlike through libpcap).
 *
 * @post If successful, a call to @ref snf_start is required to the
 *       Sniffer-mode NIC to deliver packets to the host.
 */
SNF_FUNC(int) snf_ring_open_id(snf_handle_t devhandle, int ring_id, snf_ring_t *ringh);

/**
 * Close a ring
 *
 * This function is used to inform the underlying device that no further
 * calls to @ref snf_ring_recv will be made.  If the device is not
 * subsequently closed (@ref snf_close), all packets that would have been
 * delivered to this ring are dropped.  Also, by calling this function,
 * users confirm that all packet processing for packets obtained on this
 * ring via @ref snf_ring_recv is complete.
 *
 * @param ringh Ring handle
 *
 * @retval 0 Successful.
 *
 * @post The user has processed the last packet obtained with 
 *       @ref snf_ring_recv and the device can safely be closed via 
 *       @ref snf_close if all other rings are also closed.
 */
SNF_FUNC(int) snf_ring_close(snf_ring_t ringh);

/**
 * Structure to describe a packet received on a data ring.
 */
struct snf_recv_req {
  void    *pkt_addr;  /**< Pointer to packet directly in data ring */
  uint32_t length;    /**< Length of packet, does not include Ethernet CRC */
  uint64_t timestamp; /**< 64-bit timestamp in nanoseconds */
  uint32_t portnum;   /**< Which port number received the packet */
  uint32_t length_data;  /**< Length of packet, with alignment in receive queue */
  uint32_t hw_hash;   /**< Hash calculated by the NIC. */
};

/**
 * @brief Receive next packet from a receive ring.
 *
 * This function is used to return the next available packet in a receive
 * ring.  The function can block indefinitely, for a specific timeout or
 * be used as a non-blocking call with a timeout of 0.
 *
 * @param ringh Ring handle (from @ref snf_ring_open)
 * @param timeout_ms Receive timeout to control how the function blocks
 * for the next packet. If the value is less than 0, the function can
 * block indefinitely.  If the value is 0, the function is guaranteed to
 * never enter a blocking state and returns EAGAIN unless there is a
 * packet waiting.  If the value is greater than 0, the caller indicates
 * a desired wait time in milliseconds.  With a non-zero wait time, the
 * function only blocks if there are no outstanding packets.  If the
 * timeout expires before a packet can be received, the function returns
 * EAGAIN (and @b not ETIMEDOUT).  In all cases, users should expect that
 * the function may return EINTR as the result of signal delivery.
 * @param recv_req Receive Packet structure, only updated when a the
 *                 function returns 0 for a successful packet receive
 *                 (@ref snf_recv_req)
 *
 * @retval 0 Successful packet delivery, recv_req is updated with packet
 *           information.
 * @retval EINTR The call was interrupted by a signal handler
 * @retval EAGAIN No packets available (only when timeout is >= 0).
 *
 * @remarks The packet returned always points directly into the receive
 * ring where the NIC has DMAed the packet (there are no copies).  As
 * such, the user obtains a pointer to library/driver allocated memory.
 * Users can modify the contents of the packets but should remain within
 * the boundaries of @b pkt_addr and @b length.
 *
 * @remarks Upon calling the function, the library assumes that the user
 * is done processing the previous packet.  The same assumption is made
 * when the ring is closed (@ref snf_ring_close).
 */
SNF_FUNC(int) snf_ring_recv(snf_ring_t ringh, int timeout_ms, struct snf_recv_req *recv_req);

/** Queue consumption information */
struct snf_ring_qinfo {
  uintptr_t q_avail;      /**< Amount of data available not yet received (approximate) */
  uintptr_t q_borrowed;   /**< Amount of data currently borrowed (exact) */
  uintptr_t q_free;       /**< Amount of free space still available (approximate) */
};

/** Receive ring information */
struct snf_ring_portinfo {
  snf_ring_t  ring;       /**< Single ring */
  uintptr_t   q_size;     /**< Size of the data queue */
  uint32_t    portcnt;    /**< How many physical ports deliver to this receive ring */
  uint32_t    portmask;   /**< Which ports deliver to this receive ring */
  uintptr_t   data_addr;  /**< Address of data ring */
  uintptr_t   data_size;  /**< Size of the data ring */ 
};

/**
 * @brief For aggregated rings, return the number of physical subrings.  If
 * the ring is not aggregated, the count is set to 1.
 */
SNF_FUNC(int)
snf_ring_portinfo_count(snf_ring_t ring, int *count);

/**
 * @brief Returns information for the ring.
 * For aggregated rings, returns information for each of the physical
 * rings.  It is up to the user to make sure they have allocated enough
 * memory to hold the information for all the physical rings in an
 * aggregated ring.
 *
 * @param ring Ring handle (from @ref snf_ring_open)
 * @param portinfo Pointer to memory allocated by the user that will be
 *        filled in with the information.
 */
SNF_FUNC(int)
snf_ring_portinfo(snf_ring_t ring, struct snf_ring_portinfo *portinfo);

/**
 * @brief Return queue information from ring
 */
SNF_FUNC(int)
snf_ring_recv_qinfo(snf_ring_t ring, struct snf_ring_qinfo *);

/**
 * @brief Receive and borrow many packets at once
 *
 * This function allows callers to receive one or more packets per call.
 * Contrary to @ref snf_ring_recv, this function assumes that callers will
 * split the functionality to receive packets (or borrow them) and the
 * functionality to return packets through @ref snf_ring_return_many.
 *
 * @param ring Ring handle (from @ref snf_ring_open)
 * @param timeout_ms Receive timeout to control how the function blocks
 *                   for the next packet. See complete documentation in
 *                   @ref snf_ring_recv.
 * @param req_vector Vector of receive packet structures provided by the
 *                   user and only updated when a packet is received.
 * @param nreq_in Number of receive packet structures provided in 
 *               @b req_vector.  No more than @b nreq_in packets can be
 *               received.
 * @param nreq_out Output value for the number of packets actually received
 *                and updated in @b req_vector
 * @param qinfo If non-NULL, the qinfo structure is updated before the
 *              function returns 0 or EAGAIN (the function is not updated
 *              for other error conditions).
 * @code
 * // See snf_ring_return_many documentation for examples
 * @endcode
 */
SNF_FUNC(int)
snf_ring_recv_many(snf_ring_t ring, int timeout_ms,
                   struct snf_recv_req *req_vector, int nreq_in, int *nreq_out,
                   struct snf_ring_qinfo *qinfo);

/**
 * @brief Return packet space to receive ring
 *
 * Under the borrow-many-return-many receive model, it is up to the user
 * to return space in the receive ring.  The user achieves this by
 * accumulating packet lengths from the @b length_data parameter from each
 * packet received and returning the space through this function call.
 *
 * @param ring Ring handle (from @ref snf_ring_open)
 * @param data_qlen Amount of data returned by previously consumed packets. As
 *                  a special case, if the value -1 is provided, all data
 *                  previously borrowed through snf_ring_recv_many will be
 *                  returned.
 * @param qinfo If non-NULL, the qinfo structure is updated before the
 *              function returns.
 *
 * @code
 * // Example that shows how the borrow-many-return-many receive model
 * // works.  Since the underlying data is a ring, we don't return a
 * // packet count, we return data space.  The library function call
 * // overhead can be amortized for high packet rates.
 * void
 * recv_dispatch(snf_ring_t ringh, void (*handler)(void *pkt, uint32_t length)
 * {
 *    struct snf_recv_req reqs[32];
 *    int rc, nreqs;
 *    int i, wait_msec = 1000;
 *    extern int do_exit;
 *    uint32_t return_length = 0;
 *
 *    while (1) {
 *       // Wait up to 1 second for at least one packet to arrive with a
 *       // maximum of 32 packets within a single call
 *       rc = snf_ring_recv_many(wrk->hring, wait_msec, reqs, 32, &nreqs, NULL);
 *       if (rc == 0) {
 *         for (i = 0; i < nreqs; i++) {
 *           // We handle each packet separately and accumulate the amount
 *           // of data each packet consumes in the ring. Because of
 *           // alignments length_data is somewhat larger than the packet
 *           // length
 *           handler(reqs[i].pkt_addr, reqs[i].length);
 *           return_length += reqs[i].length_data;
 *         }
 *         // We return the data in a single call.  We could have gathered
 *         // some queue information but not this time around (qinfo set
 *         // to NULL)
 *         rc = snf_ring_return_many(wrk->hring, return_length, NULL);
 *         assert(rc == 0);
 *         return_length = 0;
 *       }
 *       else if (rc == EINTR)
 *         if (do_exit)
 *           break;
 *    }
 * }
 * @endcode
 */
SNF_FUNC(int)
snf_ring_return_many(snf_ring_t ring, uint32_t data_qlen,
                     struct snf_ring_qinfo *qinfo);

/**
 * Structure to return statistics from a ring.  The Hardware-specific
 * counters apply to all rings as they are counted before any
 * demultiplexing to a ring is applied.
 */
struct snf_ring_stats {
  uint64_t  nic_pkt_recv;       /**< Number of packets received by Hardware Interface */
  uint64_t  nic_pkt_overflow;   /**< Number of packets dropped by Hardware Interface */ 
  uint64_t  nic_pkt_bad;        /**< Number of Bad CRC/PHY packets seen by Hardware Interface */
  uint64_t  ring_pkt_recv;      /**< Number of packets received into the receive ring */
  uint64_t  ring_pkt_overflow;  /**< Number of packets dropped because of insufficient space in receive ring */
  uint64_t  nic_bytes_recv;     /**< Number of raw bytes received by the Hardware Interface on 
                                     all rings. Each Ethernet data packet includes 8 bytes of HW 
                                     header, 4 bytes of CRC and the result is aligned to 16 bytes 
                                     such that a minimum size 60 byte packet counts for 80 bytes.  */
  uint64_t  snf_pkt_overflow;   /**< Number of packets dropped because of insufficient space in shared
                                     SNF buffering */
  uint64_t  nic_pkt_dropped;    /**<Number of packets droped, reflected in Packets Drop Filter in
				   Counters.*/
};

/** 
 * @brief Get statistics from a receive ring
 *
 * @param ringh Ring handle
 * @param stats User-provided pointer to a statistics structure 
 *              @ref snf_ring_stats, filled in by the library.
 *
 * @remarks This call is provided as a convenience and should not be
 * relied on for time-critical applications or for high levels of
 * accuracy.  Statistics are only updated by the NIC periodically.
 *
 * @warning Administrative clearing of NIC counters while a Sniffer-based
 * application is running may cause some of the counters to be incorrect.
 */
SNF_FUNC(int) snf_ring_getstats(snf_ring_t ringh, struct snf_ring_stats *stats);


/*! @defgroup injection Packet injection
 *
 * SNF Packet injection routines that can be used for independent packet
 * generation or coupled to reinject packets received with
 * @ref snf_ring_recv.
 *
 * @{ */
/*!
 * Opaque injection handle, allocated by @ref snf_inject_open.
 * There are only a limited amount of injection handles per NIC/port.
 */
typedef struct snf_inject_handle *snf_inject_t;

/**
 * @brief Open a port for injection and allocate an injection handle
 *
 * @param portnum  Ports are numbered from 0 to N-1 where 'N' is the
 *                 number of Myricom ports available on the system.
 *                 snf_getifaddrs() may be a useful utility to retrieve
 *                 the port number by interface name or mac address if
 *                 there are multiple
 *
 * @param flags Flags for injection handle. None are currently defined.
 *
 * @param handle  Injection handle allocated if the call is successful.
 *
 *
 * @retval 0 Success. An injection handle is opened and allocated.
 * @retval EBUSY Ran out of injection handles for this port
 * @retval ENOMEM Ran out of memory to allocate new injection handle
 */
SNF_FUNC(int) snf_inject_open(int portnum, int flags, snf_inject_t *handle);

/**
 * Get link speed on opened injection handle
 *
 * @param devhandle Device handle
 * @param speed Returns speed in bits-per-second for the link
 *
 * @remarks The cost of retrieving the link speed requires a function call
 *          that reads information kept in kernel host memory (i.e. no PCI bus
 *          reads).
 */
SNF_FUNC(int) snf_get_injection_speed(snf_inject_t devhandle, uint64_t *speed);

/**
 * @brief Send a packet and optionally block until send resources are
 *        available.
 *
 * This send function is optimized for high packet rate injection.  While
 * it can be coupled with a receive ring to reinject a packet, it is not
 * strictly necessary.  This function can be used as part of a packet
 * generator.  When the function returns successfully, the packet is
 * guaranteed to be completely buffered by SNF: no references are kept to
 * the input data and the caller is free to safely modify its contents.
 * A successful return does not, however, guarantee that the packet has
 * been injected into the network.  The SNF implementation may choose to
 * hold on to the packet for coalescing in order to improve packet
 * throughput.  
 *
 * @param inj Injection handle
 * @param timeout_ms Timeout in milliseconds to wait if insufficient send
 *        resources are available to inject a new packet.  Insufficient
 *        resources can be a lack of send descriptors or a full send queue
 *        ring.  If timeout_ms is 0, the function won't block for send
 *        resources and returns EAGAIN.
 * @param flags Flags (currently none).
 * @param pkt Pointer to the packet to be sent.  The packet must be a
 *        pointer to a complete Ethernet frame (without the trailing CRC)
 *        and start with a valid Ethernet header.  The hardware will
 *        append 4-CRC bytes at the end of the packet.  The maximum valid
 *        packet size is 9000 bytes and is enforced by the library.  The
 *        minimum valid packet size is 60 bytes, although any packet
 *        smaller than 60 bytes will be accepted by the library and padded
 *        by the hardware.
 * @param length The length of the packet, excluding the trailing 4 CRC
 *        bytes.
 *
 * @retval 0 Successful. The packet is buffered by SNF.
 * @retval EAGAIN Insufficient resources to send packet.  If timeout_ms is
 *                non-zero, the caller will have blocked at least that
 *                many milliseconds before resources could become
 *                available.
 * @retval EINVAL Packet length is larger than 9000 bytes.
 *
 * @post If successful, the packet is completely buffered for sending by
 *       SNF.  The implementation guarantees that it will eventually send
 *       the packet out in a timely fashion without requiring further
 *       calls into SNF.
 */
SNF_FUNC(int) snf_inject_send(snf_inject_t inj, int timeout_ms, int flags, 
                    const void *pkt, uint32_t length);

/**
 * @brief Send a packet with hardware delay and optionally block until
 *        send resources are available.
 *
 * This send function is used for paced packet injection.
 * This function can be used as part of a packet replay program.
 * When the function returns successfully, the packet is
 * guaranteed to be completely buffered by SNF: no references are kept to
 * the input data and the caller is free to safely modify its contents.
 * The SNF implementation delays transmitting the packet according to the
 * delay_ns parameter, relative to the start of the prior packet.
 *
 * @param inj Injection handle
 * @param timeout_ms Timeout in milliseconds to wait if insufficient send
 *        resources are available to inject a new packet.  Insufficient
 *        resources can be a lack of send descriptors or a full send queue
 *        ring.  If timeout_ms is 0, the function won't block for send
 *        resources and returns EAGAIN.
 * @param flags Flags (currently none).
 * @param pkt Pointer to the packet to be sent.  The packet must be a
 *        pointer to a complete Ethernet frame (without the trailing CRC)
 *        and start with a valid Ethernet header.  The hardware will
 *        append 4-CRC bytes at the end of the packet.  The maximum valid
 *        packet size is 9000 bytes and is enforced by the library.  The
 *        minimum valid packet size is 60 bytes, although any packet
 *        smaller than 60 bytes will be accepted by the library and padded
 *        by the hardware.
 * @param length The length of the packet, excluding the trailing 4 CRC
 *        bytes.
 * @param delay_ns The minimum delay between the start of the prior packet
 *        and the start of this packet.  Packets with a delay less than the
 *        time to send the prior packet are send immediately.  It is
 *        recommened to use 0 as the delta on the first packet sent.
 *
 * @retval 0 Successful. The packet is buffered by SNF.
 * @retval EAGAIN Insufficient resources to send packet.  If timeout_ms is
 *                non-zero, the caller will have blocked at least that
 *                many milliseconds before resources could become
 *                available.
 * @retval EINVAL Packet length is larger than 9000 bytes.
 * @retval ENOTSUP The hardware does not support injection pacing.
 *
 * @post If successful, the packet is completely buffered for sending by
 *       SNF.  The implementation guarantees that it will eventually send
 *       the packet out, as scheduled, without requiring further
 *       calls into SNF.
 */
SNF_FUNC(int) snf_inject_sched(snf_inject_t inj, int timeout_ms, int flags,
                    const void *pkt, uint32_t length, uint64_t delay_ns);

/**
 * @brief Fragment for snf_inject_send_v
 */
struct snf_pkt_fragment {
  const void    *ptr;  /**< Packet starting address */
  uint32_t length;     /**< Number of bytes */
};

/**
 * @brief Send a packet assembled from a vector of fragments
 *        and optionally block until send resources are available.
 *
 * This send function follows the same semantics as @ref snf_inject_send
 * except that the packet to be injected can be assembled from multiple
 * fragments (or buffers).
 *
 * @param inj Injection handle
 * @param timeout_ms Timeout in milliseconds to wait if insufficient send
 *        resources are available to inject a new packet.  Insufficient
 *        resources can be a lack of send descriptors or a full send queue
 *        ring.  If timeout_ms is 0, the function won't block for send
 *        resources and returns EAGAIN.
 * @param flags Flags (currently none).
 * @param frags_vec Pointer to a vector of 1 or more buffers/fragments that
 *        can be used to compose a complete Ethernet frame (not including
 *        the trailing CRC header).  The first fragment must point to a
 *        valid Ethernet header and the hardware will append its own
 *        (valid 4-byte CRC) at the end of the last buffer/fragment passed
 *        in the frags_vec. When all the fragments are added up, the maximum
 *        valid packet size is 9000 bytes and is enforced by the library.
 *        The minimum valid packet size is 60 bytes, although any packet
 *        smaller than 60 bytes will be accepted by the library and padded
 *        by the hardware.
 * @param nfrags Number of elements in the io vector
 * @param length_hint If non-zero, the amount is expected to be the sum of
 *        all the lengths passed in the io vector.  This parameters can
 *        help the library account for space when injecting packets.
 *
 * @retval 0 Successful. The packet is buffered by SNF.
 * @retval EAGAIN Insufficient resources to send packet.  If timeout_ms is
 *                non-zero, the caller will have blocked at least that
 *                many milliseconds before resources could become
 *                available.
 * @retval EINVAL Packet length (in length_hint or the sum of all frags_vec
 *                lens) is larger than 9000 bytes.
 *
 * @post If successful, the packet is completely buffered for send by
 *       SNF.  The implementation guarantees that it will eventually send
 *       the packet out in a timely fashion without requiring further
 *       calls into SNF.
 *
 * @code
 * // Example that takes an existing packet and prepends the existing
 * // ethernet type with a vlan header.
 * //
 * int
 * send_prepend__vlan_tag(uint16_t vtag, void *pkt, uint32_t len)
 * {
 *   uint32_t vlanhdr = htonl(0x8100 << 16 | vtag);
 *   struct snf_pkt_fragment vec[3];
 *
 *   // We assume that the input 'pkt' does not already contain a vlan tag
 *   // and that the pkt is not terminated with a CRC.  The hardware will
 *   // add the CRC.  We also use no timeout in the send meaning that the
 *   // send may return EAGAIN if there are insufficient resources to
 *   // queue the send.
 *
 *   vec[0].ptr = (void *) pkt;
 *   vec[0].length = 12; // dest and src mac
 *   vec[1].ptr = &vlanhdr;
 *   vec[1].length = sizeof(vlanhdr);
 *   vec[2].ptr = (void *)((uint8_t *)pkt + 12);
 *   vec[2].length = len - 12;
 *   len += sizeof(vlanhdr);
 *
 *   return snf_inject_send_v(hinj, 0, 0, vec, 3, len);
 * }
 * @endcode
 */
SNF_FUNC(int) snf_inject_send_v(snf_inject_t inj, int timeout_ms, int flags,
                      struct snf_pkt_fragment *frags_vec, int nfrags,
                      uint32_t length_hint);
/**
 * @brief Send a packet assembled from a vector of fragments at a scheduled
 *        point relative to the start of the prior packet and optionally
 *        block until send resources are available.
 *
 * This send function follows the same semantics as @ref snf_inject_send
 * except that the packet to be injected can be assembled from multiple
 * fragments (or buffers).
 *
 * @param inj Injection handle
 * @param timeout_ms Timeout in milliseconds to wait if insufficient send
 *        resources are available to inject a new packet.  Insufficient
 *        resources can be a lack of send descriptors or a full send queue
 *        ring.  If timeout_ms is 0, the function won't block for send
 *        resources and returns EAGAIN.
 * @param flags Flags (currently none).
 * @param frags_vec Pointer to a vector of 1 or more buffers/fragments that
 *        can be used to compose a complete Ethernet frame (not including
 *        the trailing CRC header).  The first fragment must point to a
 *        valid Ethernet header and the hardware will append its own
 *        (valid 4-byte CRC) at the end of the last buffer/fragment passed
 *        in the frags_vec. When all the fragments are added up, the maximum
 *        valid packet size is 9000 bytes and is enforced by the library.
 *        The minimum valid packet size is 60 bytes, although any packet
 *        smaller than 60 bytes will be accepted by the library and padded
 *        by the hardware.
 * @param nfrags Number of elements in the io vector
 * @param length_hint If non-zero, the amount is expected to be the sum of
 *        all the lengths passed in the io vector.  This parameters can
 *        help the library account for space when injecting packets.
 * @param delay_ns The minimum delay between the start of the prior packet
 *        and the start of this packet.  Packets with a delay less than the
 *        time to send the prior packet are send immediately.  It is
 *        recommened to use 0 as the delta on the first packet sent.
 *
 * @retval 0 Successful. The packet is buffered by SNF.
 * @retval EAGAIN Insufficient resources to send packet.  If timeout_ms is
 *                non-zero, the caller will have blocked at least that
 *                many milliseconds before resources could become
 *                available.
 * @retval EINVAL Packet length is larger than 9000 bytes.
 * @retval ENOTSUP The hardware does not support injection pacing.
 *
 * @post If successful, the packet is completely buffered for send by
 *       SNF.  The implementation guarantees that it will eventually send
 *       the packet out in a timely fashion without requiring further
 *       calls into SNF.
 *
 * @code
 * // Example that takes an existing packet and prepends the existing
 * // ethernet type with a vlan header.
 * //
 * int
 * send_prepend__vlan_tag(uint16_t vtag, void *pkt, uint32_t len)
 * {
 *   uint32_t vlanhdr = htonl(0x8100 << 16 | vtag);
 *   struct snf_pkt_fragment vec[3];
 *
 *   // We assume that the input 'pkt' does not already contain a vlan tag
 *   // and that the pkt is not terminated with a CRC.  The hardware will
 *   // add the CRC.  We also use no timeout in the send meaning that the
 *   // send may return EAGAIN if there are insufficient resources to
 *   // queue the send.
 *
 *   vec[0].ptr = (void *) pkt;
 *   vec[0].length = 12; // dest and src mac
 *   vec[1].ptr = &vlanhdr;
 *   vec[1].length = sizeof(vlanhdr);
 *   vec[2].ptr = (void *)((uint8_t *)pkt + 12);
 *   vec[2].length = len - 12;
 *   len += sizeof(vlanhdr);
 *
 *   // Schedule the packet to be sent 3 us. from the last.
 *   return snf_inject_sched_v(hinj, 0, 0, vec, 3, len, 3000);
 * }
 * @endcode
 */
SNF_FUNC(int) snf_inject_sched_v(snf_inject_t inj, int timeout_ms, int flags,
                      struct snf_pkt_fragment *frags_vec, int nfrags,
                      uint32_t length_hint, uint64_t delay_ns);
/**
 * @brief Close injection handle
 *
 * This function closes an injection handle and ensures that all pending
 * sends are sent by the NIC.
 *
 * @param inj Injection handle 
 *
 * @retval 0 Successful
 *
 * @post Once closed, the injection handle will have ensured that any
 *       pending sends have been sent out on the wire.  The handle is then
 *       made available again for the underlying port's limited amount of
 *       handles.
 */
SNF_FUNC(int) snf_inject_close(snf_inject_t inj);

/**
 * Structure to return statistics from an injection handle.  The
 * hardware-specific counters (nic_) apply to all injection handles.
 */
struct snf_inject_stats {
  uint64_t  inj_pkt_send;      /**< Number of packets sent by this injection endpoint */
  uint64_t  nic_pkt_send;       /**< Number of total packets sent by Hardware Interface */
  uint64_t  nic_bytes_send;     /**< Number of raw bytes sent by Hardware Interface (see nic_bytes_recv) */
};

/**
 * @brief Get statistics from an injection handle
 *
 * @param inj Injection Handle
 * @param stats User-provided pointer to a statistics structure 
 *        @ref snf_inject_stats, filled in by the SNF implementation.
 *
 * @remarks This call is provided as a convenience and should not be
 * relied on for time-critical applications or for high levels of
 * accuracy.  Statistics are only updated by the NIC periodically.
 *
 * @warning Administrative clearing of NIC counters while a Sniffer-based
 * application is running may cause some of the counters to be incorrect.
 */
SNF_FUNC(int) snf_inject_getstats(snf_inject_t inj, struct snf_inject_stats *stats);


/** @defgroup reflect Packet reflect to netdev (kernel stack)
 *
 * Network packets acquired through Sniffer can be reflected back into the
 * kernel path as if the device had initially sent then through to the
 * regular network stack.
 *
 * While Sniffer users are typically expected to process a significant
 * portion of their packets with less overhead in userspace, this feature
 * is provided as a convenience to allow some packets to be processed back
 * in the kernel.  The implementation makes no explicit step to make the
 * kernel-based processing any faster than it is when Sniffer is not being
 * used (in fact, it is probably much slower).
 *
 * @{ */
/**
 * Opaque handle returned by @ref snf_netdev_reflect_enable and used
 * to reflect packets onto by @ref snf_netdev_reflect.
 */
typedef void * snf_netdev_reflect_t;

/**
 * @brief Enable a network device for packet reflection.
 *
 * @param hsnf handle for network device to reflect onto, obtained by @ref snf_open
 *
 * @param handle  Reflection handle.
 *
 *
 * @retval 0 Success. An reflection handle is enabled.
 */
SNF_FUNC(int) snf_netdev_reflect_enable(snf_handle_t hsnf, snf_netdev_reflect_t *handle);

/**
 * @brief Reflect a packet to the network device.
 *
 * @param ref_dev Reflection handle
 * @param pkt Pointer to the packet to be reflected to the network device.
 *        The packet must be a pointer to a complete Ethernet frame (without
 *        the trailing CRC) and start with a valid Ethernet header. 
 * @param length The length of the packet, excluding the trailing 4 CRC
 *        bytes.
 *
 * @retval 0 Successful. The packet is buffered by SNF.
 *
 * @post If succcessful, the packet is completely buffered into the network
 *       device receive path.
 */
SNF_FUNC(int) snf_netdev_reflect(snf_netdev_reflect_t ref_dev, const void *pkt, uint32_t length);



#ifdef __cplusplus
}
#endif
#endif /* _snf_h */
